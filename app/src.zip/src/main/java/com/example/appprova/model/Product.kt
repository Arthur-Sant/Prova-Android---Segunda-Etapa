package com.example.appprova.model

data class Product(
    var image: Int = 0,
    var name: String = "",
    var description: String = "",
    var prince: Double = 0.0
)
